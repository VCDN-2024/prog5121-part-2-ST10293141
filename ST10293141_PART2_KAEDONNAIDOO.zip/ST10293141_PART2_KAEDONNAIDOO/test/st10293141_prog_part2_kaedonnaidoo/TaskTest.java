
package st10293141_prog_part2_kaedonnaidoo;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testCheckTaskDescription() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        assertTrue(task.checkTaskDescription());

        Task longTask = new Task("LongTaskName", "This is a very long task description that exceeds 50 characters", "Developer", 10, 1);
        assertFalse(longTask.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        assertEquals("TA:1:LOP", task.printTaskDetails());

        Task longTask = new Task("LongTaskName", "Short description", "LongDeveloperName", 10, 1);
        assertEquals("LO:1:AME", longTask.printTaskDetails());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("TaskName", "Short description", "Developer", 10, 1);
        task.setTaskStatus("InProgress");
        assertEquals("Task Status: InProgress\n" +
                     "Developer Details: Developer\n" +
                     "Task Number: 1\n" +
                     "Task Name: TaskName\n" +
                     "Task Description: Short description\n" +
                     "Task ID: TA:1:LOP\n" +
                     "Task Duration: 10 hours", task.printTaskDetails());
    }
}