
package st10293141_prog_part2_kaedonnaidoo;

public class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    // Constructor to initialize the Task object
    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, int taskNumber) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskNumber = taskNumber;
        this.taskID = createTaskID();
    }

    // Method to check the task description length
    public boolean checkTaskDescription() {
        if (taskDescription.length() <= 50) {
            return true;
        } else {
            return false;
        }
    }

    // Method to create a task ID
    private String createTaskID() {
        String start = taskName.length() > 2 ? taskName.substring(0, 2) : taskName;
        String end = developerDetails.length() > 3 ? developerDetails.substring(developerDetails.length() - 3) : developerDetails;
        return (start + ":" + taskNumber + ":" + end).toUpperCase();
    }

    // Method to print task details
    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Task Duration: " + taskDuration + " hours";
    }

    // Getters and Setters for Task Status
    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    // Getter for Task Duration
    public int getTaskDuration() {
        return taskDuration;
    }
}
