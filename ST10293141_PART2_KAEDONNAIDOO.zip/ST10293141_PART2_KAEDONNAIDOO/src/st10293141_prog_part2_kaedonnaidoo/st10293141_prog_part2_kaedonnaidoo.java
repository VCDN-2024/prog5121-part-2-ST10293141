package st10293141_prog_part2_kaedonnaidoo;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class st10293141_prog_part2_kaedonnaidoo {

    public static void main(String[] args) {
       
        Register u = new Register();
        u.Credentials();
        u.checkUsername();
        u.checkPassword();
        
        Login l = new Login();
        l.checkLoginUsername();
        l.checkLoginPassword();
        
        // Calling specific variables from another class and assigning them to another variable
        String RegUsername = u.username;
        String RegPassword = u.password;
        String firstname = u.name;
        String lastname = u.surname;
        
        String LoginUsername = l.LogUsername;
        String LoginPassword = l.LogPassword;
       
        
        boolean check = false;
        // A while loop that checks whether the user logged in with the correct information
        while(!check || LoginUsername.isEmpty() || LoginPassword.isEmpty()){
            if(RegUsername.equals(LoginUsername) && RegPassword.equals(LoginPassword)){
                JOptionPane.showMessageDialog(null,"Hello " + firstname + " " + lastname +  "\nGood to see you again");
                check = true;
            
            }
            else{
                JOptionPane.showMessageDialog(null,"Username or Password incorrcect, please try again");
                l.checkLoginUsername(); // allows for re-entry of username
                l.checkLoginPassword(); // allows for re-entry of password
                LoginUsername = l.LogUsername;
                LoginPassword = l.LogPassword;
                check = false;
            }
            
        }
        
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        ArrayList<Task> tasks = new ArrayList<>();
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you want to enter?"));

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter the Task Name:");
            String taskDescription = JOptionPane.showInputDialog("Enter the Task Description:");
            String developerDetails = JOptionPane.showInputDialog("Enter the Developer's First and Last Name:");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the Task Duration in hours:"));
            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, i);
            if (task.checkTaskDescription()) {
                JOptionPane.showMessageDialog(null, "Task successfully captured");
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                i--; // Decrement i to retry this task
                continue;
            }

            String[] statuses = {"To Do", "Doing", "Done"};
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Choose the task status:",
                "Task Status", JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);
            task.setTaskStatus(taskStatus);
            tasks.add(task);
            JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

        int totalHours = tasks.stream().mapToInt(Task::getTaskDuration).sum();
        JOptionPane.showMessageDialog(null, "Total hours of all tasks: " + totalHours);
    }
}

    


